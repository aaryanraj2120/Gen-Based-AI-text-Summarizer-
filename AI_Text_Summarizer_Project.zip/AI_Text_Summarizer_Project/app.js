function computeSummary(text, maxLength) {
    const sents = splitSentences(text);
    if (sents.length <= 1) {
        const simple = text.split(/\s+/).slice(0, maxLength).join(" ");
        const w = simple.trim() ? simple.trim().split(/\s+/).length : 0;
        const c = simple.length;
        return { summary: simple, words: w, chars: c };
    }
    const tokensPer = sents.map(function(t){ return tokenize(t); });
    const vocab = new Map();
    tokensPer.forEach(function(arr){ arr.forEach(function(tok){ if (!vocab.has(tok)) vocab.set(tok, vocab.size); }); });
    const df = new Float32Array(vocab.size);
    tokensPer.forEach(function(arr){
        const seen = new Set();
        arr.forEach(function(tok){
            const id = vocab.get(tok);
            if (!seen.has(id)) { df[id]++; seen.add(id); }
        });
    });
    const idf = new Float32Array(vocab.size);
    for (let i = 0; i < idf.length; i++) {
        idf[i] = Math.log((1 + sents.length) / (1 + df[i])) + 1;
    }
    const sentenceVecs = tokensPer.map(function(arr){
        const tf = new Map();
        arr.forEach(function(t){ tf.set(t, (tf.get(t) || 0) + 1); });
        const vec = new Map();
        let sq = 0;
        tf.forEach(function(v, t){
            const id = vocab.get(t);
            const w = v * idf[id];
            vec.set(id, w);
            sq += w * w;
        });
        return { map: vec, norm: Math.sqrt(sq) || 1 };
    });
    const n = sents.length;
    const sim = [];
    for (let i = 0; i < n; i++) {
        const row = new Float32Array(n);
        for (let j = 0; j < n; j++) {
            if (i === j) continue;
            const a = sentenceVecs[i].map;
            const b = sentenceVecs[j].map;
            let dot = 0;
            const small = a.size <= b.size ? a : b;
            const large = a.size <= b.size ? b : a;
            small.forEach(function(wa, id){
                const wb = large.get(id);
                if (wb) dot += wa * wb;
            });
            const denom = sentenceVecs[i].norm * sentenceVecs[j].norm;
            row[j] = denom ? dot / denom : 0;
        }
        sim[i] = row;
    }
    const scores = textrank(sim);
    const kw = topKeywords(tokensPer, 8);
    const boosted = scores.map(function(sc, i){ return sc * (1 + sentenceBoost(tokensPer[i], kw, sents[i])); });
    const selectedIdx = mmrSelect(boosted, sim, Math.max(1, Math.round(sents.length * 0.2)));
    const orderedByPos = selectedIdx.slice().sort(function(a, b){ return a - b; });
    const assembled = [];
    let wc = 0;
    for (const i of orderedByPos) {
        const sw = sents[i].trim().split(/\s+/).length;
        if (wc + sw > maxLength) continue;
        assembled.push(sents[i].trim());
        wc += sw;
        if (wc >= maxLength) break;
    }
    if (wc < maxLength) {
        const remaining = [];
        for (let i = 0; i < sents.length; i++) {
            if (!selectedIdx.includes(i)) remaining.push({ idx: i, score: boosted[i] });
        }
        remaining.sort(function(a,b){ return b.score - a.score || a.idx - b.idx; });
        for (let r = 0; r < remaining.length && wc < maxLength; r++) {
            const i = remaining[r].idx;
            const sw = sents[i].trim().split(/\s+/).length;
            if (wc + sw > maxLength) continue;
            assembled.push(sents[i].trim());
            wc += sw;
        }
    }
    let resultText = assembled.length ? assembled.join(" ") : text.split(/\s+/).slice(0, maxLength).join(" ");
    const clipped = resultText.split(/\s+/).slice(0, maxLength).join(" ");
    const w2 = clipped.trim() ? clipped.trim().split(/\s+/).length : 0;
    const c2 = clipped.length;
    return { summary: clipped, words: w2, chars: c2 };
}

function updateStats() {
    const text = document.getElementById("inputText").value;
    const words = text.trim() ? text.trim().split(/\s+/).length : 0;
    const chars = text.length;
    document.getElementById("inputStats").textContent = words + " words · " + chars + " characters";
}

function summarizeText() {
    const textArea = document.getElementById("inputText");
    const text = textArea.value;
    const maxLength = parseInt(document.getElementById("maxLength").value, 10) || 120;
    const output = document.getElementById("outputText");
    const loader = document.getElementById("loader");
    const summaryStats = document.getElementById("summaryStats");
    const autoChk = document.getElementById("autoTranslateSummary");
    const summaryLangSel = document.getElementById("summaryLang");

    if (!text.trim()) {
        alert("Please enter text!");
        textArea.focus();
        return;
    }

    loader.style.display = "inline-flex";
    output.innerHTML = "";

    if (window.Worker) {
        try {
            if (!window._sumWorker) {
                window._sumWorker = new Worker("summarizer.worker.js");
            }
            window._sumWorker.onmessage = function(e){
                var result = e.data;
                output.textContent = result.summary || "";
                saveInputToHistory(text);
                summaryStats.textContent = (result.words || 0) + " words · " + (result.chars || 0) + " characters";
                loader.style.display = "none";
                var lng = (summaryLangSel && summaryLangSel.value) || "en";
                if (autoChk && autoChk.checked && lng && lng !== "en") {
                    translateSummary(true);
                }
            };
            window._sumWorker.postMessage({ text: text, maxLength: maxLength });
            return;
        } catch (err) {}
    }
    const fallback = computeSummary(text, maxLength);
    output.textContent = fallback.summary;
    saveInputToHistory(text);
    summaryStats.textContent = fallback.words + " words · " + fallback.chars + " characters";
    loader.style.display = "none";
    var lng2 = (summaryLangSel && summaryLangSel.value) || "en";
    if (autoChk && autoChk.checked && lng2 && lng2 !== "en") {
        translateSummary(true);
    }
}

var summaryPlaceholderHtml = '<div class="placeholder">Your summary will appear here. Click "Summarize" to generate a condensed version of your text while keeping the key ideas.</div>';

function splitSentences(t) {
    const s = t.replace(/\s+/g, " ").trim();
    const m = s.match(/[^.!?]+[.!?]?/g);
    return m ? m : [s];
}
function tokenize(s) {
    const stop = stopwordsSet();
    return s.toLowerCase().replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter(w => w && !stop.has(w)).map(stem);
}
function stopwordsSet() {
    return new Set(["the","is","in","at","of","a","an","and","or","to","for","on","with","as","by","this","that","from","it","be","are","was","were","has","have","but","not","you","your","yours","our","ours","their","they","we","i","he","she","them","then","than","so","if","also","about","into","out","over","under","between","within","without"]);
}
function stem(w) {
    if (w.length < 4) return w;
    return w.replace(/(ing|ed|ies|s)$/,"").replace(/(ment|tion|ness)$/,"");
}
function textrank(sim) {
    const n = sim.length;
    const d = 0.85;
    const scores = new Float32Array(n).fill(1 / n);
    const outSum = new Float32Array(n);
    for (let i = 0; i < n; i++) {
        let s = 0; for (let j = 0; j < n; j++) s += sim[i][j];
        outSum[i] = s || 1;
    }
    for (let it = 0; it < 30; it++) {
        const next = new Float32Array(n).fill((1 - d) / n);
        for (let i = 0; i < n; i++) {
            for (let j = 0; j < n; j++) {
                if (sim[j][i] > 0) next[i] += d * (sim[j][i] / outSum[j]) * scores[j];
            }
        }
        let diff = 0;
        for (let k = 0; k < n; k++) diff += Math.abs(next[k] - scores[k]);
        scores.set(next);
        if (diff < 1e-4) break;
    }
    return Array.from(scores);
}
function topKeywords(tokensPer, k) {
    const freq = new Map();
    tokensPer.flat().forEach(t => freq.set(t, (freq.get(t) || 0) + 1));
    return Array.from(freq.entries()).sort((a,b)=>b[1]-a[1]).slice(0,k).map(x=>x[0]);
}
function sentenceBoost(tokens, kw, sentRaw) {
    let boost = 0;
    const set = new Set(kw);
    let hits = 0;
    tokens.forEach(t => { if (set.has(t)) hits++; });
    if (hits) boost += Math.min(0.3, hits * 0.05);
    const caps = (sentRaw.match(/\b[A-Z][a-z]+/g) || []).length;
    if (caps) boost += Math.min(0.2, caps * 0.03);
    return boost;
}
function mmrSelect(scores, sim, k) {
    const selected = [];
    const candidates = scores.map(function(_, i){ return i; });
    const λ = 0.7;
    while (selected.length < k && candidates.length) {
        let best = -Infinity, bestId = null;
        for (let idx = 0; idx < candidates.length; idx++) {
            const i = candidates[idx];
            let maxRed = 0;
            for (const s of selected) maxRed = Math.max(maxRed, sim[i][s]);
            const val = λ * scores[i] - (1 - λ) * maxRed;
            if (val > best) { best = val; bestId = i; }
        }
        if (bestId == null) break;
        selected.push(bestId);
        const pos = candidates.indexOf(bestId);
        if (pos !== -1) candidates.splice(pos, 1);
    }
    return selected;
}
function clearAll() {
    document.getElementById("inputText").value = "";
    document.getElementById("fileInput").value = "";
    document.getElementById("fileName").textContent = "";
    document.getElementById("uploadZone").classList.remove("has-file");
    document.getElementById("outputText").innerHTML = summaryPlaceholderHtml;
    document.getElementById("inputStats").textContent = "0 words · 0 characters";
    document.getElementById("summaryStats").textContent = "0 words · 0 characters";
}

function getSummaryText() {
    const output = document.getElementById("outputText");
    const text = output.textContent.trim();
    return text;
}

function copySummary() {
    const text = getSummaryText();
    if (!text) {
        alert("There is no summary to copy yet.");
        return;
    }
    navigator.clipboard.writeText(text).then(function() {
        alert("Summary copied to clipboard!");
    }).catch(function() {
        alert("Could not copy summary. Your browser may not support clipboard access here.");
    });
}

function _initVoices() {
    if (!('speechSynthesis' in window)) return;
    try {
        window._voices = window.speechSynthesis.getVoices();
        window.speechSynthesis.onvoiceschanged = function(){
            window._voices = window.speechSynthesis.getVoices();
        };
    } catch (_) {}
}
_initVoices();

function pickVoiceForLang(langCode) {
    var voices = window._voices || [];
    if (!voices.length) voices = (window.speechSynthesis && window.speechSynthesis.getVoices()) || [];
    var code = (langCode || "en").toLowerCase();
    var direct = voices.find(function(v){ return (v.lang || "").toLowerCase().startsWith(code); });
    if (direct) return direct;
    var map = {
        "en": ["en-US","en-GB","en-IN"],
        "hi": ["hi-IN"],
        "es": ["es-ES","es-MX"],
        "fr": ["fr-FR","fr-CA"],
        "de": ["de-DE"],
        "it": ["it-IT"],
        "pt": ["pt-PT","pt-BR"],
        "ru": ["ru-RU"],
        "zh": ["zh-CN","zh-TW"],
        "ja": ["ja-JP"],
        "ko": ["ko-KR"],
        "ar": ["ar-SA"],
        "tr": ["tr-TR"],
        "vi": ["vi-VN"],
        "id": ["id-ID"]
    };
    var prefs = map[code] || ["en-US","en-GB"];
    for (var i=0;i<prefs.length;i++){
        var v = voices.find(function(x){ return (x.lang || "").toLowerCase().startsWith(prefs[i].toLowerCase()); });
        if (v) return v;
    }
    return voices[0] || null;
}

function speakSummary() {
    var text = getSummaryText();
    if (!text) { alert("Generate a summary first."); return; }
    if (!('speechSynthesis' in window)) { alert("Audio playback is not supported in this browser."); return; }
    try {
        window.speechSynthesis.cancel();
        var sel = document.getElementById("summaryLang");
        var lang = (sel && sel.value) || "en";
        var u = new SpeechSynthesisUtterance(text);
        var v = pickVoiceForLang(lang);
        if (v) u.voice = v;
        u.lang = lang;
        u.rate = 1.0;
        u.pitch = 1.0;
        window.speechSynthesis.speak(u);
    } catch (e) {
        alert("Could not play audio. Try again.");
    }
}

function setSummaryPreset(preset) {
    var input = document.getElementById("maxLength");
    var val = 120;
    if (preset === "short") val = 50;
    else if (preset === "moderate") val = 120;
    else if (preset === "detailed") val = 250;
    input.value = val;
    summarizeText();
}

async function loadTranslationLanguages() {
    var inputSel = document.getElementById("inputLang");
    var summarySel = document.getElementById("summaryLang");
    if (!inputSel || !summarySel) return;
    var langs = [];
    try {
        var r0 = await fetch("/api/languages", { headers: { "Accept": "application/json" } });
        if (r0.ok) langs = await r0.json();
        if (!Array.isArray(langs) || !langs.length) {
            var hosts = ["https://libretranslate.de","https://libretranslate.com","https://translate.argosopentech.com"];
            for (var h = 0; h < hosts.length; h++) {
                try {
                    var r = await fetch(hosts[h] + "/languages", { headers: { "Accept": "application/json" } });
                    if (r.ok) { langs = await r.json(); if (Array.isArray(langs) && langs.length) break; }
                } catch (_) {}
            }
        }
    } catch (e) {
        langs = [];
    }
    if (!Array.isArray(langs) || !langs.length) {
        langs = [
            { code: "en", name: "English" },
            { code: "hi", name: "Hindi" },
            { code: "bn", name: "Bengali" },
            { code: "ur", name: "Urdu" },
            { code: "ta", name: "Tamil" },
            { code: "te", name: "Telugu" },
            { code: "mr", name: "Marathi" },
            { code: "gu", name: "Gujarati" },
            { code: "kn", name: "Kannada" },
            { code: "ml", name: "Malayalam" },
            { code: "pa", name: "Punjabi" },
            { code: "es", name: "Spanish" },
            { code: "fr", name: "French" },
            { code: "de", name: "German" },
            { code: "it", name: "Italian" },
            { code: "pt", name: "Portuguese" },
            { code: "ru", name: "Russian" },
            { code: "zh", name: "Chinese" },
            { code: "ja", name: "Japanese" },
            { code: "ko", name: "Korean" },
            { code: "ar", name: "Arabic" },
            { code: "tr", name: "Turkish" },
            { code: "vi", name: "Vietnamese" },
            { code: "id", name: "Indonesian" },
            { code: "fa", name: "Persian" },
            { code: "he", name: "Hebrew" },
            { code: "th", name: "Thai" },
            { code: "ms", name: "Malay" },
            { code: "sw", name: "Swahili" },
            { code: "ne", name: "Nepali" },
            { code: "si", name: "Sinhala" },
            { code: "my", name: "Burmese" },
            { code: "am", name: "Amharic" },
            { code: "zu", name: "Zulu" },
            { code: "ro", name: "Romanian" },
            { code: "pl", name: "Polish" },
            { code: "nl", name: "Dutch" },
            { code: "sv", name: "Swedish" },
            { code: "no", name: "Norwegian" },
            { code: "fi", name: "Finnish" },
            { code: "el", name: "Greek" },
            { code: "uk", name: "Ukrainian" },
            { code: "cs", name: "Czech" },
            { code: "sk", name: "Slovak" },
            { code: "hu", name: "Hungarian" }
        ];
    }
    function fill(sel) {
        sel.innerHTML = "";
        langs.forEach(function(l) {
            var opt = document.createElement("option");
            opt.value = l.code;
            opt.textContent = l.name;
            sel.appendChild(opt);
        });
        sel.value = "en";
    }
    fill(inputSel);
    fill(summarySel);
}

async function translateTextApi(text, target) {
    const parts = chunkForTranslate(text, 4000);
    const out = [];
    let any = false;
    for (let i = 0; i < parts.length; i++) {
        const piece = parts[i];
        const controller = new AbortController();
        const t = setTimeout(function(){ controller.abort(); }, 12000);
        try {
            let translated = "";
            try {
                const rLocal = await fetch("/api/translate", {
                    method: "POST",
                    headers: { "Content-Type": "application/json", "Accept": "application/json" },
                    body: JSON.stringify({ q: piece, source: "auto", target: target, format: "text" }),
                    signal: controller.signal
                });
                if (rLocal.ok) {
                    const jLocal = await rLocal.json();
                    translated = (jLocal && (jLocal.translatedText || jLocal.text)) || "";
                    if (translated) any = true;
                }
            } catch (_) {}
            if (!translated) {
                const hosts = ["https://libretranslate.de","https://libretranslate.com","https://translate.argosopentech.com"];
                for (let h = 0; h < hosts.length; h++) {
                    try {
                        const r = await fetch(hosts[h] + "/translate", {
                            method: "POST",
                            headers: { "Content-Type": "application/json", "Accept": "application/json" },
                            body: JSON.stringify({ q: piece, source: "auto", target: target, format: "text" }),
                            signal: controller.signal
                        });
                        if (!r.ok) continue;
                        const j = await r.json();
                        translated = (j && (j.translatedText || j.text)) || "";
                        if (translated) { any = true; break; }
                    } catch (_) {}
                }
            }
            out.push(translated || "");
        } catch (e) {
            out.push("");
        } finally {
            clearTimeout(t);
        }
    }
    if (!any) return "";
    return out.join("") || "";
}
function chunkForTranslate(text, max) {
    if (text.length <= max) return [text];
    const sents = splitSentences(text);
    const buckets = [];
    let cur = "";
    for (let i = 0; i < sents.length; i++) {
        const next = (cur ? cur + " " : "") + sents[i];
        if (next.length > max && cur) { buckets.push(cur); cur = sents[i]; }
        else { cur = next; }
    }
    if (cur) buckets.push(cur);
    return buckets;
}

async function translateInput() {
    var ta = document.getElementById("inputText");
    var sel = document.getElementById("inputLang");
    var btn = document.getElementById("inputTranslateBtn");
    if (!ta || !sel) return;
    var text = ta.value.trim();
    if (!text) { alert("Enter text first."); return; }
    var lang = sel.value || "en";
    if (btn) { btn.disabled = true; btn.textContent = "Translating…"; }
    try {
        var out = await translateTextApi(text, lang);
        if (out && out.trim()) {
            ta.value = out;
            updateStats();
        } else {
            alert("Translate failed or language unsupported by current providers.");
        }
    } catch (e) {
        alert("Could not translate. Try again later.");
    } finally {
        if (btn) { btn.disabled = false; btn.textContent = "Translate"; }
    }
}

async function translateSummary(silent) {
    var sel = document.getElementById("summaryLang");
    var btn = document.getElementById("summaryTranslateBtn");
    var output = document.getElementById("outputText");
    var stats = document.getElementById("summaryStats");
    if (!sel || !output) return;
    var text = getSummaryText();
    if (!text) { alert("Generate a summary first."); return; }
    var lang = sel.value || "en";
    if (btn) { btn.disabled = true; btn.textContent = "Translating…"; }
    try {
        var out = await translateTextApi(text, lang);
        if (out && out.trim()) {
            output.textContent = out;
            var w = out.trim() ? out.trim().split(/\s+/).length : 0;
            var c = out.length;
            if (stats) stats.textContent = w + " words · " + c + " characters";
        } else {
            if (!silent) alert("Translate failed or language unsupported by current providers.");
        }
    } catch (e) {
        if (!silent) alert("Could not translate. Try again later.");
    } finally {
        if (btn) { btn.disabled = false; btn.textContent = "Translate"; }
    }
}

function downloadSummaryPdf() {
    const text = getSummaryText();
    if (!text) {
        alert("Generate a summary first, then download as PDF.");
        return;
    }
    fetch("/api/pdf", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: text })
    }).then(function(r){
        if (!r.ok) throw new Error("server");
        return r.blob();
    }).then(function(b){
        var url = URL.createObjectURL(b);
        var a = document.createElement("a");
        a.href = url;
        a.download = "summary.pdf";
        document.body.appendChild(a);
        a.click();
        setTimeout(function(){
            URL.revokeObjectURL(url);
            a.remove();
        }, 1000);
    }).catch(function(){
        alert("PDF export is not available right now.");
    });
}

function downloadSummaryWord() {
    var text = getSummaryText();
    if (!text) {
        alert("Generate a summary first, then download as Word.");
        return;
    }
    var paragraphs = text.split(/\n+/).map(function(p) {
        return "<p>" + p.replace(/</g, '&lt;').replace(/>/g, '&gt;') + "</p>";
    }).join('');
    var html = '<!DOCTYPE html><html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word"><head><meta charset="utf-8"><title>Summary</title></head><body>' + paragraphs + '</body></html>';
    var blob = new Blob(['\ufeff' + html], { type: 'application/msword' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'summary.doc';
    a.click();
    URL.revokeObjectURL(a.href);
}

function downloadSummaryPpt() {
    var text = getSummaryText();
    if (!text) {
        alert("Generate a summary first, then download as PowerPoint.");
        return;
    }
    if (typeof PptxGenJS === 'undefined') {
        alert("PPT export is still loading. Try again in a moment.");
        return;
    }
    var pptx = new PptxGenJS();
    var slide = pptx.addSlide();
    slide.addText(text, { x: 0.5, y: 0.5, w: 9, h: 6.5, fontSize: 14, align: 'left', valign: 'top', wrap: true });
    pptx.writeFile({ fileName: 'summary.pptx' });
}

async function extractTextFromPDF(file) {
    if (typeof pdfjsLib === 'undefined') {
        alert("PDF library is still loading. Please try again in a moment.");
        return "";
    }
    var arrayBuffer = await file.arrayBuffer();
    var pdf = await pdfjsLib.getDocument(arrayBuffer).promise;
    var fullText = "";
    for (var i = 1; i <= pdf.numPages; i++) {
        var page = await pdf.getPage(i);
        var content = await page.getTextContent();
        var strings = content.items.map(function(item) { return item.str; });
        fullText += strings.join(" ") + "\n";
    }
    return fullText.replace(/\s+/g, " ").trim();
}

async function extractTextFromDocx(file) {
    if (typeof mammoth === 'undefined') {
        alert("Word library is still loading. Please try again in a moment.");
        return "";
    }
    var arrayBuffer = await file.arrayBuffer();
    var result = await mammoth.extractRawText({ arrayBuffer: arrayBuffer });
    return (result.value || "").replace(/\s+/g, " ").trim();
}

async function extractTextFromPptx(file) {
    if (typeof JSZip === 'undefined') {
        alert("PPT library is still loading. Please try again in a moment.");
        return "";
    }
    var arrayBuffer = await file.arrayBuffer();
    var zip = await JSZip.loadAsync(arrayBuffer);
    var slides = [];
    var i = 1;
    while (true) {
        var path = "ppt/slides/slide" + i + ".xml";
        var entry = zip.file(path);
        if (!entry) break;
        var xml = await entry.async("string");
        var parser = new DOMParser();
        var doc = parser.parseFromString(xml, "text/xml");
        var text = doc.documentElement.textContent || "";
        slides.push(text.replace(/\s+/g, " ").trim());
        i++;
    }
    return slides.join("\n\n").trim();
}

function onFileSelected(file) {
    if (!file) return;
    var type = file.type;
    var isPdf = type === "application/pdf";
    var isWord = type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" || (file.name || "").toLowerCase().endsWith(".docx");
    var isPpt = type === "application/vnd.openxmlformats-officedocument.presentationml.presentation" || (file.name || "").toLowerCase().endsWith(".pptx");
    if (!isPdf && !isWord && !isPpt) {
        alert("Please choose a PDF, Word (.docx), or PowerPoint (.pptx) file.");
        return;
    }
    var zone = document.getElementById("uploadZone");
    var fileNameEl = document.getElementById("fileName");
    var textArea = document.getElementById("inputText");
    fileNameEl.textContent = isPdf ? "Reading PDF…" : (isWord ? "Reading Word…" : "Reading PowerPoint…");
    zone.classList.add("has-file");
    var promise;
    if (isPdf) promise = extractTextFromPDF(file);
    else if (isWord) promise = extractTextFromDocx(file);
    else promise = extractTextFromPptx(file);
    promise.then(function(text) {
        textArea.value = text || "";
        updateStats();
        fileNameEl.textContent = file.name;
    }).catch(function(err) {
        console.error(err);
        fileNameEl.textContent = "Could not read file.";
        zone.classList.remove("has-file");
    });
}

function setupFileUpload() {
    var input = document.getElementById("fileInput");
    var zone = document.getElementById("uploadZone");
    if (!input || !zone) return;
    input.addEventListener("change", function() {
        var file = this.files && this.files[0];
        onFileSelected(file);
    });
    zone.addEventListener("dragover", function(e) {
        e.preventDefault();
        zone.classList.add("dragover");
    });
    zone.addEventListener("dragleave", function() {
        zone.classList.remove("dragover");
    });
    zone.addEventListener("drop", function(e) {
        e.preventDefault();
        zone.classList.remove("dragover");
        var file = e.dataTransfer.files && e.dataTransfer.files[0];
        if (file) onFileSelected(file);
        else alert("Please drop a PDF, Word, or PowerPoint file.");
    });
}
setupFileUpload();

var _inputTextEl = document.getElementById("inputText");
if (_inputTextEl) _inputTextEl.addEventListener("input", updateStats);

(function initBinaryBg() {
    var el = document.getElementById("binaryBg");
    if (!el) return;
    var cellW = 28;
    var cellH = 36;
    var cols = Math.ceil(window.innerWidth / cellW);
    var rows = Math.ceil(window.innerHeight / cellH);
    var size = Math.min(cellW, cellH) - 2;
    el.style.setProperty("--cols", cols);
    el.style.setProperty("--rows", rows);
    el.style.setProperty("--binary-size", size + "px");
    var total = Math.min(cols * rows, 1600);
    for (var i = 0; i < total; i++) {
        var span = document.createElement("span");
        span.textContent = Math.random() > 0.5 ? "1" : "0";
        span.style.animationDelay = (Math.random() * 1.2) + "s";
        el.appendChild(span);
    }
})();

loadTranslationLanguages();

function getInputHistory() {
    try {
        var raw = localStorage.getItem("inputHistory") || "[]";
        var arr = JSON.parse(raw);
        if (!Array.isArray(arr)) arr = [];
        return arr;
    } catch (e) {
        return [];
    }
}

function setInputHistory(arr) {
    var maxItems = 20;
    if (arr.length > maxItems) arr = arr.slice(arr.length - maxItems);
    localStorage.setItem("inputHistory", JSON.stringify(arr));
}

function saveInputToHistory(text) {
    var t = (text || "").trim();
    if (!t) return;
    var arr = getInputHistory();
    var last = arr[arr.length - 1];
    if (!last || last.text !== t) {
        arr.push({ text: t, ts: Date.now() });
        setInputHistory(arr);
        renderInputHistory();
    }
}

function renderInputHistory() {
    var panel = document.getElementById("inputHistoryPanel");
    var list = document.getElementById("inputHistoryList");
    if (!panel || !list) return;
    var arr = getInputHistory();
    if (!arr.length) {
        list.className = "history-empty";
        list.textContent = "No history yet";
        return;
    }
    var html = "";
    for (var i = arr.length - 1; i >= 0; i--) {
        var item = arr[i];
        var preview = item.text.replace(/\s+/g, " ").slice(0, 60);
        var words = item.text.trim() ? item.text.trim().split(/\s+/).length : 0;
        html += '<div class="history-item">' +
            '<div class="history-title" title="' + preview.replace(/"/g, "&quot;") + '">' + preview + '</div>' +
            '<div class="history-meta">' + words + 'w</div>' +
            '<div class="history-actions">' +
            '<button class="tiny" onclick="loadHistoryItem(' + i + ')">Load</button>' +
            '<button class="secondary tiny" title="Delete" onclick="deleteHistoryItem(' + i + ')">🗑</button>' +
            '</div>' +
            '</div>';
    }
    list.className = "";
    list.innerHTML = html;
}

function toggleInputHistory() {
    var panel = document.getElementById("inputHistoryPanel");
    if (!panel) return;
    var isShown = panel.style.display === "block";
    panel.style.display = isShown ? "none" : "block";
    if (!isShown) renderInputHistory();
}

function loadHistoryItem(index) {
    var arr = getInputHistory();
    if (!arr[index]) return;
    var ta = document.getElementById("inputText");
    ta.value = arr[index].text;
    updateStats();
    var panel = document.getElementById("inputHistoryPanel");
    if (panel) panel.style.display = "none";
}

function deleteHistoryItem(index) {
    var arr = getInputHistory();
    if (!arr[index]) return;
    arr.splice(index, 1);
    setInputHistory(arr);
    renderInputHistory();
}

function clearAllInputHistory() {
    var ok = confirm("Clear all input history?");
    if (!ok) return;
    setInputHistory([]);
    renderInputHistory();
    var panel = document.getElementById("inputHistoryPanel");
    if (panel) panel.style.display = "none";
    alert("Input history cleared.");
}

function aiAppendMessage(role, text) {
    var box = document.getElementById("aiChatMessages");
    if (!box) return;
    var wrap = document.createElement("div");
    wrap.className = "ai-msg" + (role === "user" ? " user" : "");
    var label = document.createElement("div");
    label.className = "label";
    label.textContent = role === "user" ? "You" : "AI";
    var bubble = document.createElement("div");
    bubble.className = "bubble";
    bubble.textContent = text;
    wrap.appendChild(label);
    wrap.appendChild(bubble);
    box.appendChild(wrap);
    box.scrollTop = box.scrollHeight;
}

function aiTokens(s) {
    return s.toLowerCase().replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter(Boolean);
}

function aiChatSend() {
    var input = document.getElementById("aiChatInput");
    if (!input) return;
    var q = input.value.trim();
    if (!q) return;
    aiAppendMessage("user", q);
    input.value = "";
    aiChatRespond(q);
}

function aiChatRespond(question) {
    var summary = getSummaryText();
    if (!summary) {
        aiAppendMessage("ai", "Generate a summary first, then ask a question about it.");
        return;
    }
    var stop = new Set(["the","is","in","at","of","a","an","and","or","to","for","on","with","as","by","this","that","from","it","be","are","was","were","has","have","will","would","can","could","should","if","then","than","but","so","because","about"]);
    var qTokens = aiTokens(question).filter(function(w){ return !stop.has(w); });
    if (qTokens.length === 0) {
        aiAppendMessage("ai", "Please include some keywords in your question.");
        return;
    }
    var sents = summary.replace(/\s+/g, " ").match(/[^.!?]+[.!?]?/g) || [summary];
    var scored = sents.map(function(s){
        var sTokens = aiTokens(s).filter(function(w){ return !stop.has(w); });
        var set = new Set(sTokens);
        var score = 0;
        for (var i=0;i<qTokens.length;i++){
            if (set.has(qTokens[i])) score += 1;
        }
        return { s: s.trim(), score: score };
    });
    scored.sort(function(a,b){ return b.score - a.score; });
    var best = scored.filter(function(x){ return x.score > 0; }).slice(0,2).map(function(x){ return x.s; });
    if (best.length) {
        aiAppendMessage("ai", best.join(" "));
    } else {
        aiAppendMessage("ai", "I couldn't find that in the summary. Try increasing max words and re‑summarize.");
    }
}

var aiInputEl = document.getElementById("aiChatInput");
if (aiInputEl) {
    aiInputEl.addEventListener("keydown", function(e){
        if (e.key === "Enter") {
            e.preventDefault();
            aiChatSend();
        }
    });
}

(function initMascot(){
    var mascot = document.getElementById("mascot");
    var face = document.getElementById("mascotFace");
    var mouth = document.getElementById("mascotMouth");
    var speech = document.getElementById("mascotSpeech");
    if (!mascot || !face || !mouth || !speech) return;
    var eyes = face.querySelectorAll(".pupil");
    var tRx = 0, tRy = 0, cRx = 0, cRy = 0;
    var tPx = 0, tPy = 0, cPx = 0, cPy = 0;
    var active = false;
    var idleTimer = null;
    document.addEventListener("mousemove", function(e){
        var fr = face.getBoundingClientRect();
        var cx = fr.left + fr.width/2;
        var cy = fr.top + fr.height/2;
        var vx = e.clientX - cx;
        var vy = e.clientY - cy;
        var maxTilt = 12;
        tRx = Math.max(-maxTilt, Math.min(maxTilt, -vy / (fr.height/2) * maxTilt));
        tRy = Math.max(-maxTilt, Math.min(maxTilt,  vx / (fr.width/2) * maxTilt));
        var mag = Math.sqrt(vx*vx + vy*vy);
        var lim = 6;
        var ux = mag ? vx / mag : 0;
        var uy = mag ? vy / mag : 0;
        tPx = ux * lim;
        tPy = uy * lim;
        active = true;
        if (idleTimer) clearTimeout(idleTimer);
        idleTimer = setTimeout(function(){ active = false; }, 4000);
    });
    function raf(){
        if (active) {
            cRx += (tRx - cRx) * 0.12;
            cRy += (tRy - cRy) * 0.12;
            cPx += (tPx - cPx) * 0.2;
            cPy += (tPy - cPy) * 0.2;
            face.style.transform = "rotateX(" + cRx.toFixed(2) + "deg) rotateY(" + cRy.toFixed(2) + "deg)";
            eyes.forEach(function(p){ p.style.transform = "translate(" + cPx.toFixed(2) + "px," + cPy.toFixed(2) + "px)"; });
        }
        requestAnimationFrame(raf);
    }
    requestAnimationFrame(raf);
    function setMouth(kind){
        mouth.classList.remove("smile","open","o","grin");
        mouth.classList.add(kind);
    }
    function talk(text){
        speech.textContent = text;
        mascot.classList.add("talk");
        setTimeout(function(){ mascot.classList.remove("talk"); }, 2200);
    }
    var phrases = [
        "Please use me!",
        "Summarize me!",
        "Feed me text!",
        "I'm all eyes 👀",
        "Try upload 📄",
        "Let's condense!"
    ];
    var faces = ["smile","open","o","grin"];
    var idx = 0;
    function cycle(){
        idx = (idx + 1) % faces.length;
        setMouth(faces[idx]);
        talk(phrases[Math.floor(Math.random()*phrases.length)]);
    }
    var timer = setInterval(cycle, 6000);
    mascot.addEventListener("mouseenter", function(){
        talk("Hi!");
        setMouth("grin");
    });
    mascot.addEventListener("mouseleave", function(){
        setMouth("smile");
    });
    mascot.addEventListener("click", function(){
        cycle();
    });
    function blink(){
        var es = face.querySelectorAll(".eye");
        es.forEach(function(e){ e.style.transform = "scaleY(0.2)"; });
        setTimeout(function(){ es.forEach(function(e){ e.style.transform = "scaleY(1)"; }); }, 140);
    }
    setInterval(function(){ blink(); }, 3000 + Math.random()*2000);
})();
