function splitSentences(t) {
  var s = t.replace(/\s+/g, " ").trim();
  var m = s.match(/[^.!?]+[.!?]?/g);
  return m ? m : [s];
}
function stopwordsSet() {
  return new Set(["the","is","in","at","of","a","an","and","or","to","for","on","with","as","by","this","that","from","it","be","are","was","were","has","have","but","not","you","your","yours","our","ours","their","they","we","i","he","she","them","then","than","so","if","also","about","into","out","over","under","between","within","without"]);
}
function stem(w) {
  if (w.length < 4) return w;
  return w.replace(/(ing|ed|ies|s)$/,"").replace(/(ment|tion|ness)$/,"");
}
function tokenize(s) {
  var stop = stopwordsSet();
  return s.toLowerCase().replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter(function(w){ return w && !stop.has(w); }).map(stem);
}
function textrank(sim) {
  var n = sim.length;
  var d = 0.85;
  var scores = new Float32Array(n).fill(1 / n);
  var outSum = new Float32Array(n);
  for (var i = 0; i < n; i++) {
    var s = 0; for (var j = 0; j < n; j++) s += sim[i][j];
    outSum[i] = s || 1;
  }
  for (var it = 0; it < 30; it++) {
    var next = new Float32Array(n).fill((1 - d) / n);
    for (var a = 0; a < n; a++) {
      for (var b = 0; b < n; b++) {
        if (sim[b][a] > 0) next[a] += d * (sim[b][a] / outSum[b]) * scores[b];
      }
    }
    var diff = 0;
    for (var k = 0; k < n; k++) diff += Math.abs(next[k] - scores[k]);
    scores.set(next);
    if (diff < 1e-4) break;
  }
  return Array.from(scores);
}
function topKeywords(tokensPer, k) {
  var freq = new Map();
  tokensPer.flat().forEach(function(t){ freq.set(t, (freq.get(t) || 0) + 1); });
  return Array.from(freq.entries()).sort(function(a,b){ return b[1]-a[1]; }).slice(0,k).map(function(x){ return x[0]; });
}
function sentenceBoost(tokens, kw, sentRaw) {
  var boost = 0;
  var set = new Set(kw);
  var hits = 0;
  tokens.forEach(function(t){ if (set.has(t)) hits++; });
  if (hits) boost += Math.min(0.3, hits * 0.05);
  var caps = (sentRaw.match(/\b[A-Z][a-z]+/g) || []).length;
  if (caps) boost += Math.min(0.2, caps * 0.03);
  return boost;
}
function mmrSelect(scores, sim, k) {
  var selected = [];
  var candidates = scores.map(function(_, i){ return i; });
  var l = 0.7;
  while (selected.length < k && candidates.length) {
    var best = -Infinity, bestId = null;
    for (var idx = 0; idx < candidates.length; idx++) {
      var i = candidates[idx];
      var maxRed = 0;
      for (var s = 0; s < selected.length; s++) maxRed = Math.max(maxRed, sim[i][selected[s]]);
      var val = l * scores[i] - (1 - l) * maxRed;
      if (val > best) { best = val; bestId = i; }
    }
    if (bestId == null) break;
    selected.push(bestId);
    var pos = candidates.indexOf(bestId);
    if (pos !== -1) candidates.splice(pos, 1);
  }
  return selected;
}
function computeSummary(text, maxLength) {
  var sents = splitSentences(text);
  if (sents.length <= 1) {
    var simple = text.split(/\s+/).slice(0, maxLength).join(" ");
    var w = simple.trim() ? simple.trim().split(/\s+/).length : 0;
    var c = simple.length;
    return { summary: simple, words: w, chars: c };
  }
  var tokensPer = sents.map(function(t){ return tokenize(t); });
  var vocab = new Map();
  tokensPer.forEach(function(arr){ arr.forEach(function(tok){ if (!vocab.has(tok)) vocab.set(tok, vocab.size); }); });
  var df = new Float32Array(vocab.size);
  tokensPer.forEach(function(arr){
    var seen = new Set();
    arr.forEach(function(tok){
      var id = vocab.get(tok);
      if (!seen.has(id)) { df[id]++; seen.add(id); }
    });
  });
  var idf = new Float32Array(vocab.size);
  for (var i = 0; i < idf.length; i++) idf[i] = Math.log((1 + sents.length) / (1 + df[i])) + 1;
  var sentenceVecs = tokensPer.map(function(arr){
    var tf = new Map();
    arr.forEach(function(t){ tf.set(t, (tf.get(t) || 0) + 1); });
    var vec = new Map();
    var sq = 0;
    tf.forEach(function(v, t){
      var id = vocab.get(t);
      var w = v * idf[id];
      vec.set(id, w);
      sq += w * w;
    });
    return { map: vec, norm: Math.sqrt(sq) || 1 };
  });
  var n = sents.length;
  var sim = [];
  for (var a = 0; a < n; a++) {
    var row = new Float32Array(n);
    for (var b = 0; b < n; b++) {
      if (a === b) continue;
      var A = sentenceVecs[a].map;
      var B = sentenceVecs[b].map;
      var dot = 0;
      var small = A.size <= B.size ? A : B;
      var large = A.size <= B.size ? B : A;
      small.forEach(function(wa, id){
        var wb = large.get(id);
        if (wb) dot += wa * wb;
      });
      var denom = sentenceVecs[a].norm * sentenceVecs[b].norm;
      row[b] = denom ? dot / denom : 0;
    }
    sim[a] = row;
  }
  var scores = textrank(sim);
  var kw = topKeywords(tokensPer, 8);
  var boosted = scores.map(function(sc, i){ return sc * (1 + sentenceBoost(tokensPer[i], kw, sents[i])); });
  var selectedIdx = mmrSelect(boosted, sim, Math.max(1, Math.round(sents.length * 0.2)));
  var orderedByPos = selectedIdx.slice().sort(function(a, b){ return a - b; });
  var assembled = [];
  var wc = 0;
  for (var x = 0; x < orderedByPos.length; x++) {
    var i = orderedByPos[x];
    var sw = sents[i].trim().split(/\s+/).length;
    if (wc + sw > maxLength) continue;
    assembled.push(sents[i].trim());
    wc += sw;
    if (wc >= maxLength) break;
  }
  if (wc < maxLength) {
    var remaining = [];
    for (var i = 0; i < sents.length; i++) {
      if (selectedIdx.indexOf(i) === -1) remaining.push({ idx: i, score: boosted[i] });
    }
    remaining.sort(function(a,b){ return b.score - a.score || a.idx - b.idx; });
    for (var r = 0; r < remaining.length && wc < maxLength; r++) {
      var ii = remaining[r].idx;
      var sw2 = sents[ii].trim().split(/\s+/).length;
      if (wc + sw2 > maxLength) continue;
      assembled.push(sents[ii].trim());
      wc += sw2;
    }
  }
  var resultText = assembled.length ? assembled.join(" ") : text.split(/\s+/).slice(0, maxLength).join(" ");
  var clipped = resultText.split(/\s+/).slice(0, maxLength).join(" ");
  var w2 = clipped.trim() ? clipped.trim().split(/\s+/).length : 0;
  var c2 = clipped.length;
  return { summary: clipped, words: w2, chars: c2 };
}
onmessage = function(e){
  var data = e.data || {};
  var text = data.text || "";
  var maxLength = data.maxLength || 120;
  var res = computeSummary(text, maxLength);
  postMessage(res);
};
