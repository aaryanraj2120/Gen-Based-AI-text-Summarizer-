from flask import Flask, request, jsonify, send_from_directory, Response
from flask_cors import CORS
from transformers import pipeline
import json
import urllib.request
import urllib.error
import urllib.parse
import math

app = Flask(__name__)

# Enable CORS so the HTML file can call the API even when opened directly
CORS(app)

summarizer = None

@app.route("/", methods=["GET"])
def index():
    """
    Serve the frontend HTML from this folder.
    Visit http://127.0.0.1:5000/ in your browser.
    """
    return send_from_directory(".", "index.html")

@app.route("/<path:filename>", methods=["GET"])
def serve_file(filename: str):
    return send_from_directory(".", filename)

@app.route("/login", methods=["GET"])
def login():
    return send_from_directory(".", "login.html")

_jspdf_cache = None
@app.route("/lib/jspdf.js", methods=["GET"])
def lib_jspdf():
    global _jspdf_cache
    if not _jspdf_cache:
        srcs = [
            "https://cdn.jsdelivr.net/npm/jspdf@2.5.2/dist/jspdf.umd.min.js",
            "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.2/jspdf.umd.min.js",
        ]
        for u in srcs:
            try:
                _jspdf_cache = _fetch_text(u, timeout=12, headers={"Accept": "application/javascript"})
                if _jspdf_cache:
                    break
            except Exception:
                continue
        if not _jspdf_cache:
            _jspdf_cache = ""
    return Response(_jspdf_cache, mimetype="application/javascript")

def _pdf_escape(s: str) -> str:
    return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")

def build_simple_pdf(text: str) -> bytes:
    lines = []
    for raw in text.splitlines():
        words = raw.split()
        cur = ""
        for w in words:
            if len(cur) + len(w) + 1 > 90:
                lines.append(cur)
                cur = w
            else:
                cur = w if not cur else cur + " " + w
        if cur:
            lines.append(cur)
    if not lines:
        lines = [""]
    page_w, page_h = 612, 792  # Letter
    margin = 50
    leading = 16
    y = page_h - margin
    stream_cmds = ["BT", "/F1 12 Tf", f"{margin} {y} Td"]
    stream_cmds.append(f"({_pdf_escape(lines[0])}) Tj")
    for i in range(1, len(lines)):
        stream_cmds.append(f"0 -{leading} Td")
        stream_cmds.append(f"({_pdf_escape(lines[i])}) Tj")
    stream_cmds.append("ET")
    stream = "\n".join(stream_cmds).encode("utf-8")
    obj1 = b"<< /Type /Catalog /Pages 2 0 R >>"
    obj2 = b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>"
    obj3 = f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {page_w} {page_h}] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>".encode("utf-8")
    obj4 = b"<< /Type /Font /Subtype /Type1 /Name /F1 /BaseFont /Helvetica >>"
    obj5 = f"<< /Length {len(stream)} >>\nstream\n".encode("utf-8") + stream + b"\nendstream"
    parts = []
    parts.append(b"%PDF-1.4\n")
    offsets = [0]
    def add_obj(n, data):
        parts.append(f"{n} 0 obj\n".encode("utf-8"))
        parts.append(data)
        parts.append(b"\nendobj\n")
    add_obj(1, obj1)
    add_obj(2, obj2)
    add_obj(3, obj3)
    add_obj(4, obj4)
    add_obj(5, obj5)
    # Build final body and compute xref
    body = b""
    xref_offsets = [0]  # object 0
    pos = 0
    for p in parts:
        body += p
    # Now compute offsets for each object
    # Reconstruct to get offsets
    body2 = b"%PDF-1.4\n"
    xref_offsets = [0]
    objs = [
        (1, obj1), (2, obj2), (3, obj3), (4, obj4), (5, obj5)
    ]
    pos = len(body2)
    for n, data in objs:
        xref_offsets.append(pos)
        body2 += f"{n} 0 obj\n".encode("utf-8") + data + b"\nendobj\n"
        pos = len(body2)
    xref_start = len(body2)
    xref = "xref\n0 6\n".encode("utf-8")
    xref += b"0000000000 65535 f \n"
    for off in xref_offsets[1:]:
        xref += f"{off:010d} 00000 n \n".encode("utf-8")
    trailer = f"trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n{xref_start}\n%%EOF\n".encode("utf-8")
    pdf = body2 + xref + trailer
    return pdf

@app.route("/api/pdf", methods=["POST"])
def api_pdf():
    body = request.get_json(force=True) or {}
    text = body.get("text", "")
    data = build_simple_pdf(text)
    return Response(data, mimetype="application/pdf", headers={
        "Content-Disposition": "attachment; filename=summary.pdf"
    })

@app.route("/summarize", methods=["POST"])
def summarize():
    data = request.json
    text = data["text"]
    max_length = int(data.get("max_length", 120))

    global summarizer
    if summarizer is None:
        summarizer = pipeline("summarization", model="facebook/bart-large-cnn")
    summary = summarizer(text, max_length=max_length, min_length=40, do_sample=False)

    return jsonify({
        "summary": summary[0]["summary_text"]
    })

def _fetch_json(url, payload=None, timeout=10, headers=None):
    if headers is None:
        headers = {"Accept": "application/json", "Content-Type": "application/json"}
    data = None
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers, method="POST" if data else "GET")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        b = resp.read()
        return json.loads(b.decode("utf-8"))

def _fetch_text(url, timeout=10, headers=None):
    req = urllib.request.Request(url, headers=headers or {}, method="GET")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        b = resp.read()
        return b.decode("utf-8", errors="replace")

@app.route("/api/languages", methods=["GET"])
def languages():
    hosts = ["https://libretranslate.de", "https://libretranslate.com", "https://translate.argosopentech.com"]
    langs = None
    for h in hosts:
        try:
            langs = _fetch_json(h + "/languages", payload=None, timeout=8, headers={"Accept": "application/json"})
            if isinstance(langs, list) and len(langs) > 0:
                break
        except Exception:
            continue
    if not isinstance(langs, list) or not langs:
        langs = [
            {"code": "en", "name": "English"},
            {"code": "hi", "name": "Hindi"},
            {"code": "bn", "name": "Bengali"},
            {"code": "ur", "name": "Urdu"},
            {"code": "ta", "name": "Tamil"},
            {"code": "te", "name": "Telugu"},
            {"code": "mr", "name": "Marathi"},
            {"code": "gu", "name": "Gujarati"},
            {"code": "kn", "name": "Kannada"},
            {"code": "ml", "name": "Malayalam"},
            {"code": "pa", "name": "Punjabi"},
            {"code": "es", "name": "Spanish"},
            {"code": "fr", "name": "French"},
            {"code": "de", "name": "German"},
            {"code": "it", "name": "Italian"},
            {"code": "pt", "name": "Portuguese"},
            {"code": "ru", "name": "Russian"},
            {"code": "zh", "name": "Chinese"},
            {"code": "ja", "name": "Japanese"},
            {"code": "ko", "name": "Korean"},
            {"code": "ar", "name": "Arabic"},
            {"code": "tr", "name": "Turkish"},
            {"code": "vi", "name": "Vietnamese"},
            {"code": "id", "name": "Indonesian"},
            {"code": "fa", "name": "Persian"},
            {"code": "he", "name": "Hebrew"},
            {"code": "th", "name": "Thai"},
            {"code": "ms", "name": "Malay"},
            {"code": "sw", "name": "Swahili"},
            {"code": "ne", "name": "Nepali"},
            {"code": "si", "name": "Sinhala"},
            {"code": "my", "name": "Burmese"},
            {"code": "am", "name": "Amharic"},
            {"code": "zu", "name": "Zulu"},
            {"code": "ro", "name": "Romanian"},
            {"code": "pl", "name": "Polish"},
            {"code": "nl", "name": "Dutch"},
            {"code": "sv", "name": "Swedish"},
            {"code": "no", "name": "Norwegian"},
            {"code": "fi", "name": "Finnish"},
            {"code": "el", "name": "Greek"},
            {"code": "uk", "name": "Ukrainian"},
            {"code": "cs", "name": "Czech"},
            {"code": "sk", "name": "Slovak"},
            {"code": "hu", "name": "Hungarian"},
        ]
    return jsonify(langs)

@app.route("/api/translate", methods=["POST"])
def api_translate():
    body = request.get_json(force=True) or {}
    q = body.get("q", "")
    src = body.get("source", "auto")
    tgt = body.get("target", "en")
    fmt = body.get("format", "text")
    key = body.get("api_key")
    hosts = ["https://libretranslate.de", "https://libretranslate.com", "https://translate.argosopentech.com"]
    result = ""
    provider = None
    for h in hosts:
        try:
            payload = {"q": q, "source": src, "target": tgt, "format": fmt}
            if key: payload["api_key"] = key
            j = _fetch_json(h + "/translate", payload=payload, timeout=12)
            result = (j.get("translatedText") or j.get("text") or "")
            if result:
                provider = h
                break
        except Exception:
            continue
    if not result:
        try:
            pair = (src if src != "auto" else "auto") + "|" + tgt
            url = "https://api.mymemory.translated.net/get?q=" + urllib.parse.quote(q) + "&langpair=" + urllib.parse.quote(pair)
            j = _fetch_json(url, payload=None, timeout=12, headers={"Accept": "application/json"})
            result = j.get("responseData", {}).get("translatedText", "") or ""
            if result:
                provider = "mymemory"
        except Exception:
            pass
    ok = bool(result)
    return jsonify({"translatedText": result, "ok": ok, "provider": provider})

if __name__ == "__main__":
    app.run(debug=True)
