describe('tokenize', function(){
  it('removes stopwords and stems', function(){
    var out = tokenize("The quick, brown foxes jumped over 13 lazy dogs!");
    expect(out).to.deep.equal(["quick","brown","foxe","jump","13","lazy","dog"]);
  });
});

describe('splitSentences', function(){
  it('splits text into sentences', function(){
    var s = splitSentences("Hello world! How are you? Fine.");
    expect(s.length).to.equal(3);
    expect(s[0].trim()).to.equal("Hello world!");
  });
});

describe('textrank', function(){
  it('returns non-negative scores of correct length', function(){
    var sim = [
      new Float32Array([0,0.5,0]),
      new Float32Array([0.5,0,0.2]),
      new Float32Array([0,0.2,0])
    ];
    var scores = textrank(sim);
    expect(scores.length).to.equal(3);
    expect(scores.every(function(x){ return x >= 0; })).to.equal(true);
  });
});

describe('mmrSelect', function(){
  it('selects top items with zero redundancy', function(){
    var sim = [new Float32Array(3), new Float32Array(3), new Float32Array(3)];
    var sel = mmrSelect([0.9,0.6,0.1], sim, 2);
    expect(sel).to.deep.equal([sel[0], sel[1]]);
    expect(sel).to.deep.equal([0,1]);
  });
});

describe('chunkForTranslate', function(){
  it('splits into buckets under max length', function(){
    var text = Array(100).fill("Sentence. ").join("");
    var chunks = chunkForTranslate(text, 50);
    expect(chunks.length).to.be.greaterThan(1);
    expect(chunks.every(function(c){ return c.length <= 50; })).to.equal(true);
  });
});

describe('computeSummary', function(){
  it('returns summary and stats', function(){
    var res = computeSummary("A. B. C. D. E.", 10);
    expect(res.summary.length).to.be.greaterThan(0);
    expect(res.words).to.be.greaterThan(0);
    expect(res.chars).to.be.greaterThan(0);
  });
  it('runs under 2000ms on large input', function(){
    var sents = [];
    for (var i = 0; i < 300; i++) {
      sents.push("This is a sentence number " + i + " with some repeated words and tokens to process.");
    }
    var text = sents.join(" ");
    var t0 = performance.now();
    var res = computeSummary(text, 120);
    var t1 = performance.now();
    expect(res.summary.length).to.be.greaterThan(0);
    expect(t1 - t0).to.be.below(2000);
  });
});
